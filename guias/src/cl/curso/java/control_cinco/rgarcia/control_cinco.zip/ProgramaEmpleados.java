/**
 * 
 */
package cl.curso.java.control_cinco.rgarcia;

/**
 * @author Royerliz
 *
 */
public class ProgramaEmpleados {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
